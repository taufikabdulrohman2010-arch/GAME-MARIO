extends Node2D

@export var player_controller: PlayerController
@export var animation_player: AnimationPlayer
@export var sprite: Sprite2D

func _process(_delta):
	# ngabalik character sprite 
	if player_controller.direction == 1:
		sprite.flip_h = false
	elif  player_controller.direction == -1:
		sprite.flip_h = true
	# muter animation character
	if abs(player_controller.velocity.x) > 0.0:
		animation_player.play("move")
	else:
		animation_player.play("idle")
	# muter animation ngajol
	if player_controller.velocity.y < 0.0:
		animation_player.play("jump")
	elif player_controller.velocity.y > 0.0:
		animation_player.play("fall")
